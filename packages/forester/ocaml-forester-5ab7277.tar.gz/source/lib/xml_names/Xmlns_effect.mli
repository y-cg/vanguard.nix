(*
 * SPDX-FileCopyrightText: 2024 The Forester Project Contributors
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 *)

open Types

module Make () : sig
  val normalise_qname : xml_qname -> xml_qname
  val within_scope : (unit -> 'a) -> xmlns_attr list * 'a
  val find_xmlns_for_prefix : string -> string option
  val run : reserved:xmlns_attr list -> (unit -> 'a) -> 'a
end
